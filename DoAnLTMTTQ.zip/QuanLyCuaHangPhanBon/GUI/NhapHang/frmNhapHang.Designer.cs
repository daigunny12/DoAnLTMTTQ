﻿namespace GUI.NhapHang
{
    partial class frmNhapHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle25 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle26 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle27 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblTenNV = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblDatetime = new System.Windows.Forms.Label();
            this.btnThemHoaDon = new System.Windows.Forms.Button();
            this.btnResetHoaDon = new System.Windows.Forms.Button();
            this.lblChucVu = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblTongcong = new System.Windows.Forms.Label();
            this.lblNocucuahang = new System.Windows.Forms.Label();
            this.lblTonghh = new System.Windows.Forms.Label();
            this.lblTongsl = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.cbTenncc = new System.Windows.Forms.ComboBox();
            this.lblGhichu = new System.Windows.Forms.Label();
            this.lblDiachi = new System.Windows.Forms.Label();
            this.lblSdt = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.pntable = new System.Windows.Forms.Panel();
            this.dtgNhaphang = new System.Windows.Forms.DataGridView();
            this.Stt = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MaHH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TenHH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DonViTinh = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SoLuong = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GiaMua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ThanhTien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GhiChu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnThanhtoan = new System.Windows.Forms.Button();
            this.pnTile = new System.Windows.Forms.Panel();
            this.label11 = new System.Windows.Forms.Label();
            this.pnTongThongTin = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnThemNCC = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.pntable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtgNhaphang)).BeginInit();
            this.pnTile.SuspendLayout();
            this.pnTongThongTin.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel1.Controls.Add(this.lblTenNV);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.lblDatetime);
            this.panel1.Controls.Add(this.btnThemHoaDon);
            this.panel1.Controls.Add(this.btnResetHoaDon);
            this.panel1.Controls.Add(this.lblChucVu);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(536, 215);
            this.panel1.TabIndex = 0;
            // 
            // lblTenNV
            // 
            this.lblTenNV.AutoSize = true;
            this.lblTenNV.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenNV.Location = new System.Drawing.Point(113, 60);
            this.lblTenNV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTenNV.Name = "lblTenNV";
            this.lblTenNV.Size = new System.Drawing.Size(75, 27);
            this.lblTenNV.TabIndex = 7;
            this.lblTenNV.Text = "tenNV";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(7, 58);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(92, 27);
            this.label12.TabIndex = 6;
            this.label12.Text = "Tên NV:";
            // 
            // lblDatetime
            // 
            this.lblDatetime.AutoSize = true;
            this.lblDatetime.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDatetime.Location = new System.Drawing.Point(4, 18);
            this.lblDatetime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDatetime.Name = "lblDatetime";
            this.lblDatetime.Size = new System.Drawing.Size(104, 27);
            this.lblDatetime.TabIndex = 5;
            this.lblDatetime.Text = "DateNow";
            // 
            // btnThemHoaDon
            // 
            this.btnThemHoaDon.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F);
            this.btnThemHoaDon.Location = new System.Drawing.Point(281, 164);
            this.btnThemHoaDon.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemHoaDon.Name = "btnThemHoaDon";
            this.btnThemHoaDon.Size = new System.Drawing.Size(217, 43);
            this.btnThemHoaDon.TabIndex = 4;
            this.btnThemHoaDon.Text = "Thêm Hóa Đơn";
            this.btnThemHoaDon.UseVisualStyleBackColor = true;
            this.btnThemHoaDon.Click += new System.EventHandler(this.btnThemHoaDon_Click);
            // 
            // btnResetHoaDon
            // 
            this.btnResetHoaDon.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetHoaDon.Location = new System.Drawing.Point(32, 164);
            this.btnResetHoaDon.Margin = new System.Windows.Forms.Padding(4);
            this.btnResetHoaDon.Name = "btnResetHoaDon";
            this.btnResetHoaDon.Size = new System.Drawing.Size(211, 43);
            this.btnResetHoaDon.TabIndex = 3;
            this.btnResetHoaDon.Text = "Tạo Mới Hóa Đơn";
            this.btnResetHoaDon.UseVisualStyleBackColor = true;
            this.btnResetHoaDon.Click += new System.EventHandler(this.btnResetHoaDon_Click);
            // 
            // lblChucVu
            // 
            this.lblChucVu.AutoSize = true;
            this.lblChucVu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChucVu.Location = new System.Drawing.Point(113, 99);
            this.lblChucVu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblChucVu.Name = "lblChucVu";
            this.lblChucVu.Size = new System.Drawing.Size(82, 27);
            this.lblChucVu.TabIndex = 1;
            this.lblChucVu.Text = "chucvu";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(7, 98);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(106, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "Chức vụ :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.lblTongcong);
            this.panel2.Controls.Add(this.lblNocucuahang);
            this.panel2.Controls.Add(this.lblTonghh);
            this.panel2.Controls.Add(this.lblTongsl);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(536, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(351, 215);
            this.panel2.TabIndex = 1;
            // 
            // lblTongcong
            // 
            this.lblTongcong.AutoSize = true;
            this.lblTongcong.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongcong.ForeColor = System.Drawing.Color.Red;
            this.lblTongcong.Location = new System.Drawing.Point(249, 164);
            this.lblTongcong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTongcong.Name = "lblTongcong";
            this.lblTongcong.Size = new System.Drawing.Size(24, 27);
            this.lblTongcong.TabIndex = 6;
            this.lblTongcong.Text = "0";
            // 
            // lblNocucuahang
            // 
            this.lblNocucuahang.AutoSize = true;
            this.lblNocucuahang.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNocucuahang.Location = new System.Drawing.Point(249, 92);
            this.lblNocucuahang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNocucuahang.Name = "lblNocucuahang";
            this.lblNocucuahang.Size = new System.Drawing.Size(24, 27);
            this.lblNocucuahang.TabIndex = 5;
            this.lblNocucuahang.Text = "0";
            // 
            // lblTonghh
            // 
            this.lblTonghh.AutoSize = true;
            this.lblTonghh.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTonghh.Location = new System.Drawing.Point(249, 11);
            this.lblTonghh.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTonghh.Name = "lblTonghh";
            this.lblTonghh.Size = new System.Drawing.Size(24, 27);
            this.lblTonghh.TabIndex = 4;
            this.lblTonghh.Text = "0";
            // 
            // lblTongsl
            // 
            this.lblTongsl.AutoSize = true;
            this.lblTongsl.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTongsl.Location = new System.Drawing.Point(249, 53);
            this.lblTongsl.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTongsl.Name = "lblTongsl";
            this.lblTongsl.Size = new System.Drawing.Size(24, 27);
            this.lblTongsl.TabIndex = 4;
            this.lblTongsl.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(29, 164);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 27);
            this.label6.TabIndex = 3;
            this.label6.Text = "Tổng cộng :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 92);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(216, 27);
            this.label5.TabIndex = 2;
            this.label5.Text = "Nợ cũ của cửa hàng :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(29, 53);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(161, 27);
            this.label4.TabIndex = 1;
            this.label4.Text = "Tổng số lượng :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(29, 11);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 27);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tổng hàng hóa :";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.panel3.Controls.Add(this.btnThemNCC);
            this.panel3.Controls.Add(this.cbTenncc);
            this.panel3.Controls.Add(this.lblGhichu);
            this.panel3.Controls.Add(this.lblDiachi);
            this.panel3.Controls.Add(this.lblSdt);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.label9);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(887, 0);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(536, 215);
            this.panel3.TabIndex = 1;
            // 
            // cbTenncc
            // 
            this.cbTenncc.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cbTenncc.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cbTenncc.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbTenncc.FormattingEnabled = true;
            this.cbTenncc.Location = new System.Drawing.Point(144, 13);
            this.cbTenncc.Margin = new System.Windows.Forms.Padding(4);
            this.cbTenncc.Name = "cbTenncc";
            this.cbTenncc.Size = new System.Drawing.Size(214, 34);
            this.cbTenncc.TabIndex = 5;
            this.cbTenncc.SelectedIndexChanged += new System.EventHandler(this.cbTenncc_SelectedIndexChanged);
            // 
            // lblGhichu
            // 
            this.lblGhichu.AutoSize = true;
            this.lblGhichu.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGhichu.Location = new System.Drawing.Point(144, 135);
            this.lblGhichu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblGhichu.Name = "lblGhichu";
            this.lblGhichu.Size = new System.Drawing.Size(0, 27);
            this.lblGhichu.TabIndex = 4;
            // 
            // lblDiachi
            // 
            this.lblDiachi.AutoSize = true;
            this.lblDiachi.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiachi.Location = new System.Drawing.Point(144, 53);
            this.lblDiachi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDiachi.Name = "lblDiachi";
            this.lblDiachi.Size = new System.Drawing.Size(0, 27);
            this.lblDiachi.TabIndex = 3;
            // 
            // lblSdt
            // 
            this.lblSdt.AutoSize = true;
            this.lblSdt.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSdt.Location = new System.Drawing.Point(144, 92);
            this.lblSdt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSdt.Name = "lblSdt";
            this.lblSdt.Size = new System.Drawing.Size(0, 27);
            this.lblSdt.TabIndex = 3;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(20, 135);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(100, 27);
            this.label10.TabIndex = 2;
            this.label10.Text = "Ghi chú :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(20, 53);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(93, 27);
            this.label9.TabIndex = 1;
            this.label9.Text = "Địa chỉ :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(20, 92);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 27);
            this.label8.TabIndex = 1;
            this.label8.Text = "SĐT :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(20, 16);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 27);
            this.label7.TabIndex = 0;
            this.label7.Text = "Tên NCC :";
            // 
            // pntable
            // 
            this.pntable.Controls.Add(this.dtgNhaphang);
            this.pntable.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pntable.Location = new System.Drawing.Point(0, 215);
            this.pntable.Margin = new System.Windows.Forms.Padding(4);
            this.pntable.Name = "pntable";
            this.pntable.Size = new System.Drawing.Size(1423, 280);
            this.pntable.TabIndex = 2;
            // 
            // dtgNhaphang
            // 
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dtgNhaphang.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dtgNhaphang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtgNhaphang.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Stt,
            this.MaHH,
            this.TenHH,
            this.DonViTinh,
            this.SoLuong,
            this.GiaMua,
            this.ThanhTien,
            this.GhiChu});
            this.dtgNhaphang.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtgNhaphang.Location = new System.Drawing.Point(0, 0);
            this.dtgNhaphang.Margin = new System.Windows.Forms.Padding(4);
            this.dtgNhaphang.Name = "dtgNhaphang";
            this.dtgNhaphang.ReadOnly = true;
            this.dtgNhaphang.Size = new System.Drawing.Size(1423, 280);
            this.dtgNhaphang.TabIndex = 0;
            this.dtgNhaphang.CellMouseDoubleClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dtgNhaphang_CellMouseDoubleClick);
            this.dtgNhaphang.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgNhaphang_CellValueChanged);
            this.dtgNhaphang.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(this.dtgNhaphang_RowPostPaint);
            // 
            // Stt
            // 
            this.Stt.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Stt.DataPropertyName = "Stt";
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.Stt.DefaultCellStyle = dataGridViewCellStyle20;
            this.Stt.HeaderText = "STT";
            this.Stt.Name = "Stt";
            this.Stt.ReadOnly = true;
            // 
            // MaHH
            // 
            this.MaHH.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.MaHH.DataPropertyName = "MaHH";
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.MaHH.DefaultCellStyle = dataGridViewCellStyle21;
            this.MaHH.HeaderText = "Mã HH";
            this.MaHH.Name = "MaHH";
            this.MaHH.ReadOnly = true;
            // 
            // TenHH
            // 
            this.TenHH.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.TenHH.DataPropertyName = "TenHH";
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.TenHH.DefaultCellStyle = dataGridViewCellStyle22;
            this.TenHH.HeaderText = "TÊN HÀNG HÓA";
            this.TenHH.Name = "TenHH";
            this.TenHH.ReadOnly = true;
            // 
            // DonViTinh
            // 
            this.DonViTinh.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.DonViTinh.DataPropertyName = "DonViTinh";
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.DonViTinh.DefaultCellStyle = dataGridViewCellStyle23;
            this.DonViTinh.HeaderText = "ĐƠN VỊ TÍNH";
            this.DonViTinh.Name = "DonViTinh";
            this.DonViTinh.ReadOnly = true;
            this.DonViTinh.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.DonViTinh.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // SoLuong
            // 
            this.SoLuong.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.SoLuong.DataPropertyName = "SoLuong";
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle24.Format = "N0";
            dataGridViewCellStyle24.NullValue = null;
            this.SoLuong.DefaultCellStyle = dataGridViewCellStyle24;
            this.SoLuong.HeaderText = "SỐ LƯỢNG";
            this.SoLuong.Name = "SoLuong";
            this.SoLuong.ReadOnly = true;
            this.SoLuong.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.SoLuong.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // GiaMua
            // 
            this.GiaMua.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.GiaMua.DataPropertyName = "GiaMua";
            dataGridViewCellStyle25.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.GiaMua.DefaultCellStyle = dataGridViewCellStyle25;
            this.GiaMua.HeaderText = "GIÁ MUA";
            this.GiaMua.Name = "GiaMua";
            this.GiaMua.ReadOnly = true;
            this.GiaMua.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.GiaMua.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ThanhTien
            // 
            this.ThanhTien.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.ThanhTien.DataPropertyName = "ThanhTien";
            dataGridViewCellStyle26.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.ThanhTien.DefaultCellStyle = dataGridViewCellStyle26;
            this.ThanhTien.HeaderText = "THÀNH TIỀN";
            this.ThanhTien.Name = "ThanhTien";
            this.ThanhTien.ReadOnly = true;
            this.ThanhTien.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ThanhTien.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // GhiChu
            // 
            this.GhiChu.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.GhiChu.DataPropertyName = "GhiChu";
            dataGridViewCellStyle27.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.GhiChu.DefaultCellStyle = dataGridViewCellStyle27;
            this.GhiChu.HeaderText = "GHI CHÚ";
            this.GhiChu.Name = "GhiChu";
            this.GhiChu.ReadOnly = true;
            // 
            // btnThanhtoan
            // 
            this.btnThanhtoan.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.btnThanhtoan.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnThanhtoan.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThanhtoan.Location = new System.Drawing.Point(1264, 0);
            this.btnThanhtoan.Margin = new System.Windows.Forms.Padding(4);
            this.btnThanhtoan.Name = "btnThanhtoan";
            this.btnThanhtoan.Size = new System.Drawing.Size(159, 59);
            this.btnThanhtoan.TabIndex = 3;
            this.btnThanhtoan.Text = "Thanh toán ";
            this.btnThanhtoan.UseVisualStyleBackColor = false;
            this.btnThanhtoan.Click += new System.EventHandler(this.btnThanhtoan_Click);
            // 
            // pnTile
            // 
            this.pnTile.Controls.Add(this.label11);
            this.pnTile.Controls.Add(this.btnThanhtoan);
            this.pnTile.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnTile.Location = new System.Drawing.Point(0, 0);
            this.pnTile.Name = "pnTile";
            this.pnTile.Size = new System.Drawing.Size(1423, 59);
            this.pnTile.TabIndex = 4;
            // 
            // label11
            // 
            this.label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(611, 10);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(214, 37);
            this.label11.TabIndex = 5;
            this.label11.Text = "NHẬP HÀNG";
            // 
            // pnTongThongTin
            // 
            this.pnTongThongTin.Controls.Add(this.panel2);
            this.pnTongThongTin.Controls.Add(this.panel3);
            this.pnTongThongTin.Controls.Add(this.panel1);
            this.pnTongThongTin.Dock = System.Windows.Forms.DockStyle.Top;
            this.pnTongThongTin.Location = new System.Drawing.Point(0, 0);
            this.pnTongThongTin.Name = "pnTongThongTin";
            this.pnTongThongTin.Size = new System.Drawing.Size(1423, 215);
            this.pnTongThongTin.TabIndex = 5;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.pntable);
            this.panel4.Controls.Add(this.pnTongThongTin);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 59);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1423, 495);
            this.panel4.TabIndex = 6;
            // 
            // btnThemNCC
            // 
            this.btnThemNCC.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemNCC.Font = new System.Drawing.Font("MS Reference Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemNCC.Location = new System.Drawing.Point(366, 12);
            this.btnThemNCC.Margin = new System.Windows.Forms.Padding(4);
            this.btnThemNCC.Name = "btnThemNCC";
            this.btnThemNCC.Size = new System.Drawing.Size(157, 37);
            this.btnThemNCC.TabIndex = 12;
            this.btnThemNCC.Text = "Thêm NCC";
            this.btnThemNCC.UseVisualStyleBackColor = true;
            this.btnThemNCC.Click += new System.EventHandler(this.btnThemNCC_Click);
            // 
            // frmNhapHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1423, 554);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.pnTile);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmNhapHang";
            this.Text = "Nhập Hàng";
            this.Load += new System.EventHandler(this.NhapHang_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.pntable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dtgNhaphang)).EndInit();
            this.pnTile.ResumeLayout(false);
            this.pnTile.PerformLayout();
            this.pnTongThongTin.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnThemHoaDon;
        private System.Windows.Forms.Button btnResetHoaDon;
        private System.Windows.Forms.Label lblChucVu;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel pntable;
        private System.Windows.Forms.DataGridView dtgNhaphang;
        private System.Windows.Forms.Label lblTongcong;
        private System.Windows.Forms.Label lblNocucuahang;
        private System.Windows.Forms.Label lblTonghh;
        private System.Windows.Forms.Label lblTongsl;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblGhichu;
        private System.Windows.Forms.Label lblDiachi;
        private System.Windows.Forms.Label lblSdt;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnThanhtoan;
        private System.Windows.Forms.ComboBox cbTenncc;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Stt;
        private System.Windows.Forms.DataGridViewTextBoxColumn MaHH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TenHH;
        private System.Windows.Forms.DataGridViewTextBoxColumn DonViTinh;
        private System.Windows.Forms.DataGridViewTextBoxColumn SoLuong;
        private System.Windows.Forms.DataGridViewTextBoxColumn GiaMua;
        private System.Windows.Forms.DataGridViewTextBoxColumn ThanhTien;
        private System.Windows.Forms.DataGridViewTextBoxColumn GhiChu;
        private System.Windows.Forms.Label lblDatetime;
        private System.Windows.Forms.Panel pnTile;
        private System.Windows.Forms.Panel pnTongThongTin;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label lblTenNV;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnThemNCC;
    }
}