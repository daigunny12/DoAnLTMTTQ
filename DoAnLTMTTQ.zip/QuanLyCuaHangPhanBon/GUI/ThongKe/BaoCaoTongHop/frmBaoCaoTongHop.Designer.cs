﻿namespace GUI.ThongKe.BaoCaoTongHop
{
    partial class frmBaoCaoTongHop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNhaphangToday = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lblNhaptongcongToday = new System.Windows.Forms.Label();
            this.lblNhapdatraToday = new System.Windows.Forms.Label();
            this.lblNhapconnoToday = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblToDay = new System.Windows.Forms.Label();
            this.lblBanHangToday = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblBantongcongToday = new System.Windows.Forms.Label();
            this.lblBandathuToday = new System.Windows.Forms.Label();
            this.lblBanconnoToday = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNhaphangYesterday = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblNhaptongcongYesterday = new System.Windows.Forms.Label();
            this.lblNhapdatraYesterday = new System.Windows.Forms.Label();
            this.lblNhapconnoYesterday = new System.Windows.Forms.Label();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label16 = new System.Windows.Forms.Label();
            this.lblYesterday = new System.Windows.Forms.Label();
            this.lblBanhangYesterday = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblBantongcongYesterday = new System.Windows.Forms.Label();
            this.lblBandathuYesterday = new System.Windows.Forms.Label();
            this.lblBanconnoYesterday = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.tableLayoutPanel6 = new System.Windows.Forms.TableLayoutPanel();
            this.lblBanhang = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.lblBantongcong = new System.Windows.Forms.Label();
            this.lblBandathu = new System.Windows.Forms.Label();
            this.lblBanconno = new System.Windows.Forms.Label();
            this.tableLayoutPanel5 = new System.Windows.Forms.TableLayoutPanel();
            this.lblNhaphang = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.lblNhaptongcong = new System.Windows.Forms.Label();
            this.lblNhapdatra = new System.Windows.Forms.Label();
            this.lblNhapconno = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.btnXem = new System.Windows.Forms.Button();
            this.dtpToDate = new System.Windows.Forms.DateTimePicker();
            this.dtpFromDate = new System.Windows.Forms.DateTimePicker();
            this.panel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.tableLayoutPanel6.SuspendLayout();
            this.tableLayoutPanel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tableLayoutPanel2);
            this.panel1.Controls.Add(this.tableLayoutPanel1);
            this.panel1.Location = new System.Drawing.Point(16, 39);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(645, 324);
            this.panel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.09091F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.90909F));
            this.tableLayoutPanel2.Controls.Add(this.lblNhaphangToday, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.label8, 0, 2);
            this.tableLayoutPanel2.Controls.Add(this.label9, 0, 3);
            this.tableLayoutPanel2.Controls.Add(this.lblNhaptongcongToday, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblNhapdatraToday, 1, 2);
            this.tableLayoutPanel2.Controls.Add(this.lblNhapconnoToday, 1, 3);
            this.tableLayoutPanel2.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel2.Location = new System.Drawing.Point(5, 158);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 4;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(636, 166);
            this.tableLayoutPanel2.TabIndex = 9;
            // 
            // lblNhaphangToday
            // 
            this.lblNhaphangToday.AutoSize = true;
            this.tableLayoutPanel2.SetColumnSpan(this.lblNhaphangToday, 2);
            this.lblNhaphangToday.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblNhaphangToday.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNhaphangToday.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblNhaphangToday.Location = new System.Drawing.Point(4, 0);
            this.lblNhaphangToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhaphangToday.Name = "lblNhaphangToday";
            this.lblNhaphangToday.Size = new System.Drawing.Size(628, 27);
            this.lblNhaphangToday.TabIndex = 3;
            this.lblNhaphangToday.Text = "NHẬP HÀNG ()";
            this.lblNhaphangToday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 27);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(162, 27);
            this.label5.TabIndex = 1;
            this.label5.Text = "TỔNG CỘNG :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 60);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(111, 27);
            this.label8.TabIndex = 4;
            this.label8.Text = "ĐÃ TRẢ :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 94);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 27);
            this.label9.TabIndex = 5;
            this.label9.Text = "CÒN NỢ :";
            // 
            // lblNhaptongcongToday
            // 
            this.lblNhaptongcongToday.AutoSize = true;
            this.lblNhaptongcongToday.Location = new System.Drawing.Point(379, 27);
            this.lblNhaptongcongToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhaptongcongToday.Name = "lblNhaptongcongToday";
            this.lblNhaptongcongToday.Size = new System.Drawing.Size(162, 27);
            this.lblNhaptongcongToday.TabIndex = 6;
            this.lblNhaptongcongToday.Text = "TỔNG CỘNG :";
            // 
            // lblNhapdatraToday
            // 
            this.lblNhapdatraToday.AutoSize = true;
            this.lblNhapdatraToday.Location = new System.Drawing.Point(379, 60);
            this.lblNhapdatraToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhapdatraToday.Name = "lblNhapdatraToday";
            this.lblNhapdatraToday.Size = new System.Drawing.Size(162, 27);
            this.lblNhapdatraToday.TabIndex = 7;
            this.lblNhapdatraToday.Text = "TỔNG CỘNG :";
            // 
            // lblNhapconnoToday
            // 
            this.lblNhapconnoToday.AutoSize = true;
            this.lblNhapconnoToday.Location = new System.Drawing.Point(379, 94);
            this.lblNhapconnoToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhapconnoToday.Name = "lblNhapconnoToday";
            this.lblNhapconnoToday.Size = new System.Drawing.Size(162, 27);
            this.lblNhapconnoToday.TabIndex = 8;
            this.lblNhapconnoToday.Text = "TỔNG CỘNG :";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.09091F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.90909F));
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblToDay, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblBanHangToday, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label3, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.label4, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.lblBantongcongToday, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblBandathuToday, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblBanconnoToday, 1, 4);
            this.tableLayoutPanel1.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel1.Location = new System.Drawing.Point(5, 4);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(632, 146);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 54);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(162, 27);
            this.label2.TabIndex = 1;
            this.label2.Text = "TỔNG CỘNG :";
            // 
            // lblToDay
            // 
            this.lblToDay.AutoSize = true;
            this.lblToDay.BackColor = System.Drawing.Color.LimeGreen;
            this.tableLayoutPanel1.SetColumnSpan(this.lblToDay, 2);
            this.lblToDay.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblToDay.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToDay.ForeColor = System.Drawing.Color.White;
            this.lblToDay.Location = new System.Drawing.Point(4, 0);
            this.lblToDay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblToDay.Name = "lblToDay";
            this.lblToDay.Size = new System.Drawing.Size(624, 27);
            this.lblToDay.TabIndex = 1;
            this.lblToDay.Text = "Hôm nay";
            this.lblToDay.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblBanHangToday
            // 
            this.lblBanHangToday.AutoSize = true;
            this.tableLayoutPanel1.SetColumnSpan(this.lblBanHangToday, 2);
            this.lblBanHangToday.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblBanHangToday.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBanHangToday.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblBanHangToday.Location = new System.Drawing.Point(4, 27);
            this.lblBanHangToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBanHangToday.Name = "lblBanHangToday";
            this.lblBanHangToday.Size = new System.Drawing.Size(624, 27);
            this.lblBanHangToday.TabIndex = 3;
            this.lblBanHangToday.Text = "BÁN HÀNG ()";
            this.lblBanHangToday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 87);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(111, 27);
            this.label3.TabIndex = 4;
            this.label3.Text = "ĐÃ THU :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 121);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 27);
            this.label4.TabIndex = 5;
            this.label4.Text = "CÒN NỢ :";
            // 
            // lblBantongcongToday
            // 
            this.lblBantongcongToday.AutoSize = true;
            this.lblBantongcongToday.Location = new System.Drawing.Point(377, 54);
            this.lblBantongcongToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBantongcongToday.Name = "lblBantongcongToday";
            this.lblBantongcongToday.Size = new System.Drawing.Size(162, 27);
            this.lblBantongcongToday.TabIndex = 6;
            this.lblBantongcongToday.Text = "TỔNG CỘNG :";
            // 
            // lblBandathuToday
            // 
            this.lblBandathuToday.AutoSize = true;
            this.lblBandathuToday.Location = new System.Drawing.Point(377, 87);
            this.lblBandathuToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBandathuToday.Name = "lblBandathuToday";
            this.lblBandathuToday.Size = new System.Drawing.Size(162, 27);
            this.lblBandathuToday.TabIndex = 7;
            this.lblBandathuToday.Text = "TỔNG CỘNG :";
            // 
            // lblBanconnoToday
            // 
            this.lblBanconnoToday.AutoSize = true;
            this.lblBanconnoToday.Location = new System.Drawing.Point(377, 121);
            this.lblBanconnoToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBanconnoToday.Name = "lblBanconnoToday";
            this.lblBanconnoToday.Size = new System.Drawing.Size(162, 27);
            this.lblBanconnoToday.TabIndex = 8;
            this.lblBanconnoToday.Text = "TỔNG CỘNG :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Red;
            this.label1.Location = new System.Drawing.Point(16, 11);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(292, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "1. BÁO CÁO NGÀY GẦN ĐÂY :";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.tableLayoutPanel3);
            this.panel2.Controls.Add(this.tableLayoutPanel4);
            this.panel2.Location = new System.Drawing.Point(669, 39);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(645, 324);
            this.panel2.TabIndex = 3;
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.09091F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.90909F));
            this.tableLayoutPanel3.Controls.Add(this.lblNhaphangYesterday, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.label10, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.label11, 0, 2);
            this.tableLayoutPanel3.Controls.Add(this.label12, 0, 3);
            this.tableLayoutPanel3.Controls.Add(this.lblNhaptongcongYesterday, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.lblNhapdatraYesterday, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.lblNhapconnoYesterday, 1, 3);
            this.tableLayoutPanel3.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel3.Location = new System.Drawing.Point(5, 177);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(636, 147);
            this.tableLayoutPanel3.TabIndex = 9;
            // 
            // lblNhaphangYesterday
            // 
            this.lblNhaphangYesterday.AutoSize = true;
            this.tableLayoutPanel3.SetColumnSpan(this.lblNhaphangYesterday, 2);
            this.lblNhaphangYesterday.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblNhaphangYesterday.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNhaphangYesterday.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblNhaphangYesterday.Location = new System.Drawing.Point(4, 0);
            this.lblNhaphangYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhaphangYesterday.Name = "lblNhaphangYesterday";
            this.lblNhaphangYesterday.Size = new System.Drawing.Size(628, 27);
            this.lblNhaphangYesterday.TabIndex = 3;
            this.lblNhaphangYesterday.Text = "NHẬP HÀNG ()";
            this.lblNhaphangYesterday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 27);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(162, 27);
            this.label10.TabIndex = 1;
            this.label10.Text = "TỔNG CỘNG :";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 60);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(111, 27);
            this.label11.TabIndex = 4;
            this.label11.Text = "ĐÃ TRẢ :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(4, 94);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(114, 27);
            this.label12.TabIndex = 5;
            this.label12.Text = "CÒN NỢ :";
            // 
            // lblNhaptongcongYesterday
            // 
            this.lblNhaptongcongYesterday.AutoSize = true;
            this.lblNhaptongcongYesterday.Location = new System.Drawing.Point(379, 27);
            this.lblNhaptongcongYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhaptongcongYesterday.Name = "lblNhaptongcongYesterday";
            this.lblNhaptongcongYesterday.Size = new System.Drawing.Size(162, 27);
            this.lblNhaptongcongYesterday.TabIndex = 6;
            this.lblNhaptongcongYesterday.Text = "TỔNG CỘNG :";
            // 
            // lblNhapdatraYesterday
            // 
            this.lblNhapdatraYesterday.AutoSize = true;
            this.lblNhapdatraYesterday.Location = new System.Drawing.Point(379, 60);
            this.lblNhapdatraYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhapdatraYesterday.Name = "lblNhapdatraYesterday";
            this.lblNhapdatraYesterday.Size = new System.Drawing.Size(162, 27);
            this.lblNhapdatraYesterday.TabIndex = 7;
            this.lblNhapdatraYesterday.Text = "TỔNG CỘNG :";
            // 
            // lblNhapconnoYesterday
            // 
            this.lblNhapconnoYesterday.AutoSize = true;
            this.lblNhapconnoYesterday.Location = new System.Drawing.Point(379, 94);
            this.lblNhapconnoYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhapconnoYesterday.Name = "lblNhapconnoYesterday";
            this.lblNhapconnoYesterday.Size = new System.Drawing.Size(162, 27);
            this.lblNhapconnoYesterday.TabIndex = 8;
            this.lblNhapconnoYesterday.Text = "TỔNG CỘNG :";
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.ColumnCount = 2;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.09091F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.90909F));
            this.tableLayoutPanel4.Controls.Add(this.label16, 0, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblYesterday, 0, 0);
            this.tableLayoutPanel4.Controls.Add(this.lblBanhangYesterday, 0, 1);
            this.tableLayoutPanel4.Controls.Add(this.label19, 0, 3);
            this.tableLayoutPanel4.Controls.Add(this.label20, 0, 4);
            this.tableLayoutPanel4.Controls.Add(this.lblBantongcongYesterday, 1, 2);
            this.tableLayoutPanel4.Controls.Add(this.lblBandathuYesterday, 1, 3);
            this.tableLayoutPanel4.Controls.Add(this.lblBanconnoYesterday, 1, 4);
            this.tableLayoutPanel4.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel4.Location = new System.Drawing.Point(5, 4);
            this.tableLayoutPanel4.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 5;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 108F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(636, 165);
            this.tableLayoutPanel4.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(4, 54);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(162, 27);
            this.label16.TabIndex = 1;
            this.label16.Text = "TỔNG CỘNG :";
            // 
            // lblYesterday
            // 
            this.lblYesterday.AutoSize = true;
            this.lblYesterday.BackColor = System.Drawing.Color.RoyalBlue;
            this.tableLayoutPanel4.SetColumnSpan(this.lblYesterday, 2);
            this.lblYesterday.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblYesterday.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYesterday.ForeColor = System.Drawing.Color.White;
            this.lblYesterday.Location = new System.Drawing.Point(4, 0);
            this.lblYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblYesterday.Name = "lblYesterday";
            this.lblYesterday.Size = new System.Drawing.Size(628, 27);
            this.lblYesterday.TabIndex = 1;
            this.lblYesterday.Text = "Hôm qua";
            this.lblYesterday.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // lblBanhangYesterday
            // 
            this.lblBanhangYesterday.AutoSize = true;
            this.tableLayoutPanel4.SetColumnSpan(this.lblBanhangYesterday, 2);
            this.lblBanhangYesterday.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblBanhangYesterday.Font = new System.Drawing.Font("Times New Roman", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBanhangYesterday.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblBanhangYesterday.Location = new System.Drawing.Point(4, 27);
            this.lblBanhangYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBanhangYesterday.Name = "lblBanhangYesterday";
            this.lblBanhangYesterday.Size = new System.Drawing.Size(628, 27);
            this.lblBanhangYesterday.TabIndex = 3;
            this.lblBanhangYesterday.Text = "BÁN HÀNG ()";
            this.lblBanhangYesterday.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(4, 87);
            this.label19.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(111, 27);
            this.label19.TabIndex = 4;
            this.label19.Text = "ĐÃ THU :";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 121);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(114, 27);
            this.label20.TabIndex = 5;
            this.label20.Text = "CÒN NỢ :";
            // 
            // lblBantongcongYesterday
            // 
            this.lblBantongcongYesterday.AutoSize = true;
            this.lblBantongcongYesterday.Location = new System.Drawing.Point(379, 54);
            this.lblBantongcongYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBantongcongYesterday.Name = "lblBantongcongYesterday";
            this.lblBantongcongYesterday.Size = new System.Drawing.Size(162, 27);
            this.lblBantongcongYesterday.TabIndex = 6;
            this.lblBantongcongYesterday.Text = "TỔNG CỘNG :";
            // 
            // lblBandathuYesterday
            // 
            this.lblBandathuYesterday.AutoSize = true;
            this.lblBandathuYesterday.Location = new System.Drawing.Point(379, 87);
            this.lblBandathuYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBandathuYesterday.Name = "lblBandathuYesterday";
            this.lblBandathuYesterday.Size = new System.Drawing.Size(162, 27);
            this.lblBandathuYesterday.TabIndex = 7;
            this.lblBandathuYesterday.Text = "TỔNG CỘNG :";
            // 
            // lblBanconnoYesterday
            // 
            this.lblBanconnoYesterday.AutoSize = true;
            this.lblBanconnoYesterday.Location = new System.Drawing.Point(379, 121);
            this.lblBanconnoYesterday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBanconnoYesterday.Name = "lblBanconnoYesterday";
            this.lblBanconnoYesterday.Size = new System.Drawing.Size(162, 27);
            this.lblBanconnoYesterday.TabIndex = 8;
            this.lblBanconnoYesterday.Text = "TỔNG CỘNG :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Red;
            this.label6.Location = new System.Drawing.Point(16, 397);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(249, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "2. BÁO CÁO TÙY CHỈNH :";
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.tableLayoutPanel6);
            this.panel3.Controls.Add(this.tableLayoutPanel5);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.btnXem);
            this.panel3.Controls.Add(this.dtpToDate);
            this.panel3.Controls.Add(this.dtpFromDate);
            this.panel3.Location = new System.Drawing.Point(16, 438);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1298, 312);
            this.panel3.TabIndex = 5;
            // 
            // tableLayoutPanel6
            // 
            this.tableLayoutPanel6.ColumnCount = 2;
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.09091F));
            this.tableLayoutPanel6.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.90909F));
            this.tableLayoutPanel6.Controls.Add(this.lblBanhang, 0, 0);
            this.tableLayoutPanel6.Controls.Add(this.label25, 0, 1);
            this.tableLayoutPanel6.Controls.Add(this.label26, 0, 2);
            this.tableLayoutPanel6.Controls.Add(this.label27, 0, 3);
            this.tableLayoutPanel6.Controls.Add(this.lblBantongcong, 1, 1);
            this.tableLayoutPanel6.Controls.Add(this.lblBandathu, 1, 2);
            this.tableLayoutPanel6.Controls.Add(this.lblBanconno, 1, 3);
            this.tableLayoutPanel6.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel6.Location = new System.Drawing.Point(13, 54);
            this.tableLayoutPanel6.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel6.Name = "tableLayoutPanel6";
            this.tableLayoutPanel6.RowCount = 4;
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel6.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel6.Size = new System.Drawing.Size(632, 254);
            this.tableLayoutPanel6.TabIndex = 12;
            // 
            // lblBanhang
            // 
            this.lblBanhang.AutoSize = true;
            this.tableLayoutPanel6.SetColumnSpan(this.lblBanhang, 2);
            this.lblBanhang.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblBanhang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBanhang.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblBanhang.Location = new System.Drawing.Point(4, 0);
            this.lblBanhang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBanhang.Name = "lblBanhang";
            this.lblBanhang.Size = new System.Drawing.Size(624, 20);
            this.lblBanhang.TabIndex = 3;
            this.lblBanhang.Text = "BÁN HÀNG ()";
            this.lblBanhang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(4, 27);
            this.label25.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(162, 27);
            this.label25.TabIndex = 1;
            this.label25.Text = "TỔNG CỘNG :";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(4, 60);
            this.label26.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(111, 27);
            this.label26.TabIndex = 4;
            this.label26.Text = "ĐÃ THU :";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(4, 94);
            this.label27.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(114, 27);
            this.label27.TabIndex = 5;
            this.label27.Text = "CÒN NỢ :";
            // 
            // lblBantongcong
            // 
            this.lblBantongcong.AutoSize = true;
            this.lblBantongcong.Location = new System.Drawing.Point(377, 27);
            this.lblBantongcong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBantongcong.Name = "lblBantongcong";
            this.lblBantongcong.Size = new System.Drawing.Size(162, 27);
            this.lblBantongcong.TabIndex = 6;
            this.lblBantongcong.Text = "TỔNG CỘNG :";
            // 
            // lblBandathu
            // 
            this.lblBandathu.AutoSize = true;
            this.lblBandathu.Location = new System.Drawing.Point(377, 60);
            this.lblBandathu.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBandathu.Name = "lblBandathu";
            this.lblBandathu.Size = new System.Drawing.Size(162, 27);
            this.lblBandathu.TabIndex = 7;
            this.lblBandathu.Text = "TỔNG CỘNG :";
            // 
            // lblBanconno
            // 
            this.lblBanconno.AutoSize = true;
            this.lblBanconno.Location = new System.Drawing.Point(377, 94);
            this.lblBanconno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblBanconno.Name = "lblBanconno";
            this.lblBanconno.Size = new System.Drawing.Size(162, 27);
            this.lblBanconno.TabIndex = 8;
            this.lblBanconno.Text = "TỔNG CỘNG :";
            // 
            // tableLayoutPanel5
            // 
            this.tableLayoutPanel5.ColumnCount = 2;
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 59.09091F));
            this.tableLayoutPanel5.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 40.90909F));
            this.tableLayoutPanel5.Controls.Add(this.lblNhaphang, 0, 0);
            this.tableLayoutPanel5.Controls.Add(this.label15, 0, 1);
            this.tableLayoutPanel5.Controls.Add(this.label17, 0, 2);
            this.tableLayoutPanel5.Controls.Add(this.label18, 0, 3);
            this.tableLayoutPanel5.Controls.Add(this.lblNhaptongcong, 1, 1);
            this.tableLayoutPanel5.Controls.Add(this.lblNhapdatra, 1, 2);
            this.tableLayoutPanel5.Controls.Add(this.lblNhapconno, 1, 3);
            this.tableLayoutPanel5.Font = new System.Drawing.Font("Times New Roman", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tableLayoutPanel5.Location = new System.Drawing.Point(658, 54);
            this.tableLayoutPanel5.Margin = new System.Windows.Forms.Padding(4);
            this.tableLayoutPanel5.Name = "tableLayoutPanel5";
            this.tableLayoutPanel5.RowCount = 4;
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 27F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 33F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel5.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 12F));
            this.tableLayoutPanel5.Size = new System.Drawing.Size(636, 258);
            this.tableLayoutPanel5.TabIndex = 11;
            // 
            // lblNhaphang
            // 
            this.lblNhaphang.AutoSize = true;
            this.tableLayoutPanel5.SetColumnSpan(this.lblNhaphang, 2);
            this.lblNhaphang.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblNhaphang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNhaphang.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblNhaphang.Location = new System.Drawing.Point(4, 0);
            this.lblNhaphang.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhaphang.Name = "lblNhaphang";
            this.lblNhaphang.Size = new System.Drawing.Size(628, 20);
            this.lblNhaphang.TabIndex = 3;
            this.lblNhaphang.Text = "NHẬP HÀNG ()";
            this.lblNhaphang.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(4, 27);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(162, 27);
            this.label15.TabIndex = 1;
            this.label15.Text = "TỔNG CỘNG :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(4, 60);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(111, 27);
            this.label17.TabIndex = 4;
            this.label17.Text = "ĐÃ TRẢ :";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(4, 94);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(114, 27);
            this.label18.TabIndex = 5;
            this.label18.Text = "CÒN NỢ :";
            // 
            // lblNhaptongcong
            // 
            this.lblNhaptongcong.AutoSize = true;
            this.lblNhaptongcong.Location = new System.Drawing.Point(379, 27);
            this.lblNhaptongcong.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhaptongcong.Name = "lblNhaptongcong";
            this.lblNhaptongcong.Size = new System.Drawing.Size(162, 27);
            this.lblNhaptongcong.TabIndex = 6;
            this.lblNhaptongcong.Text = "TỔNG CỘNG :";
            // 
            // lblNhapdatra
            // 
            this.lblNhapdatra.AutoSize = true;
            this.lblNhapdatra.Location = new System.Drawing.Point(379, 60);
            this.lblNhapdatra.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhapdatra.Name = "lblNhapdatra";
            this.lblNhapdatra.Size = new System.Drawing.Size(162, 27);
            this.lblNhapdatra.TabIndex = 7;
            this.lblNhapdatra.Text = "TỔNG CỘNG :";
            // 
            // lblNhapconno
            // 
            this.lblNhapconno.AutoSize = true;
            this.lblNhapconno.Location = new System.Drawing.Point(379, 94);
            this.lblNhapconno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNhapconno.Name = "lblNhapconno";
            this.lblNhapconno.Size = new System.Drawing.Size(162, 27);
            this.lblNhapconno.TabIndex = 8;
            this.lblNhapconno.Text = "TỔNG CỘNG :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(315, 9);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(53, 22);
            this.label7.TabIndex = 9;
            this.label7.Text = "Đến :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(8, 10);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 22);
            this.label13.TabIndex = 8;
            this.label13.Text = "Từ :";
            // 
            // btnXem
            // 
            this.btnXem.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXem.Location = new System.Drawing.Point(616, 2);
            this.btnXem.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnXem.Name = "btnXem";
            this.btnXem.Size = new System.Drawing.Size(99, 30);
            this.btnXem.TabIndex = 7;
            this.btnXem.Text = "Xem";
            this.btnXem.UseVisualStyleBackColor = true;
            this.btnXem.Click += new System.EventHandler(this.btnXem_Click);
            // 
            // dtpToDate
            // 
            this.dtpToDate.CustomFormat = "";
            this.dtpToDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpToDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpToDate.Location = new System.Drawing.Point(373, 2);
            this.dtpToDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpToDate.Name = "dtpToDate";
            this.dtpToDate.Size = new System.Drawing.Size(223, 30);
            this.dtpToDate.TabIndex = 6;
            this.dtpToDate.Value = new System.DateTime(2020, 7, 18, 0, 0, 0, 0);
            // 
            // dtpFromDate
            // 
            this.dtpFromDate.Checked = false;
            this.dtpFromDate.CustomFormat = "";
            this.dtpFromDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFromDate.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFromDate.Location = new System.Drawing.Point(71, 2);
            this.dtpFromDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtpFromDate.Name = "dtpFromDate";
            this.dtpFromDate.Size = new System.Drawing.Size(223, 30);
            this.dtpFromDate.TabIndex = 5;
            this.dtpFromDate.Value = new System.DateTime(2020, 7, 17, 0, 0, 0, 0);
            // 
            // frmBaoCaoTongHop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1321, 763);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmBaoCaoTongHop";
            this.Text = "Báo Cáo Tổng Hợp";
            this.Load += new System.EventHandler(this.BaoCaoTongHop_Load);
            this.panel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.tableLayoutPanel6.ResumeLayout(false);
            this.tableLayoutPanel6.PerformLayout();
            this.tableLayoutPanel5.ResumeLayout(false);
            this.tableLayoutPanel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblNhaphangToday;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblNhaptongcongToday;
        private System.Windows.Forms.Label lblNhapdatraToday;
        private System.Windows.Forms.Label lblNhapconnoToday;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblToDay;
        private System.Windows.Forms.Label lblBanHangToday;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblBantongcongToday;
        private System.Windows.Forms.Label lblBandathuToday;
        private System.Windows.Forms.Label lblBanconnoToday;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label lblNhaphangYesterday;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label lblNhaptongcongYesterday;
        private System.Windows.Forms.Label lblNhapdatraYesterday;
        private System.Windows.Forms.Label lblNhapconnoYesterday;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblYesterday;
        private System.Windows.Forms.Label lblBanhangYesterday;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblBantongcongYesterday;
        private System.Windows.Forms.Label lblBandathuYesterday;
        private System.Windows.Forms.Label lblBanconnoYesterday;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button btnXem;
        private System.Windows.Forms.DateTimePicker dtpToDate;
        private System.Windows.Forms.DateTimePicker dtpFromDate;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel6;
        private System.Windows.Forms.Label lblBanhang;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label lblBantongcong;
        private System.Windows.Forms.Label lblBandathu;
        private System.Windows.Forms.Label lblBanconno;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel5;
        private System.Windows.Forms.Label lblNhaphang;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label lblNhaptongcong;
        private System.Windows.Forms.Label lblNhapdatra;
        private System.Windows.Forms.Label lblNhapconno;
    }
}