﻿namespace GUI
{
    partial class supMenu
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(supMenu));
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.pnChe = new System.Windows.Forms.Panel();
            this.btnNhaCungCap = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnKhachHang = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnNhanVien = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnHangHoa = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnBaoCaoTongHop = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnNK = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnXK = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnHDNH = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnHDBH = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnCTNH = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnCTBH = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.tabPage3.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(232, 663);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "4";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.tabPage3.Controls.Add(this.btnNhaCungCap);
            this.tabPage3.Controls.Add(this.btnKhachHang);
            this.tabPage3.Controls.Add(this.btnNhanVien);
            this.tabPage3.Controls.Add(this.btnHangHoa);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(232, 663);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "2";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(232, 663);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "1";
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(3, 6);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(240, 692);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(232, 663);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "0";
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(232, 663);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "3";
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.tabPage6.Controls.Add(this.btnBaoCaoTongHop);
            this.tabPage6.Controls.Add(this.btnNK);
            this.tabPage6.Controls.Add(this.btnXK);
            this.tabPage6.Controls.Add(this.btnHDNH);
            this.tabPage6.Controls.Add(this.btnHDBH);
            this.tabPage6.Controls.Add(this.btnCTNH);
            this.tabPage6.Controls.Add(this.btnCTBH);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(232, 663);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "5";
            // 
            // pnChe
            // 
            this.pnChe.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pnChe.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.pnChe.Location = new System.Drawing.Point(-18, 3);
            this.pnChe.Name = "pnChe";
            this.pnChe.Size = new System.Drawing.Size(267, 31);
            this.pnChe.TabIndex = 1;
            // 
            // btnNhaCungCap
            // 
            this.btnNhaCungCap.Activecolor = System.Drawing.Color.White;
            this.btnNhaCungCap.BackColor = System.Drawing.Color.Transparent;
            this.btnNhaCungCap.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNhaCungCap.BorderRadius = 0;
            this.btnNhaCungCap.ButtonText = "Nhà cung cấp";
            this.btnNhaCungCap.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNhaCungCap.DisabledColor = System.Drawing.Color.Gray;
            this.btnNhaCungCap.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNhaCungCap.Iconcolor = System.Drawing.Color.Transparent;
            this.btnNhaCungCap.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnNhaCungCap.Iconimage")));
            this.btnNhaCungCap.Iconimage_right = null;
            this.btnNhaCungCap.Iconimage_right_Selected = null;
            this.btnNhaCungCap.Iconimage_Selected = null;
            this.btnNhaCungCap.IconMarginLeft = 0;
            this.btnNhaCungCap.IconMarginRight = 0;
            this.btnNhaCungCap.IconRightVisible = false;
            this.btnNhaCungCap.IconRightZoom = 0D;
            this.btnNhaCungCap.IconVisible = false;
            this.btnNhaCungCap.IconZoom = 90D;
            this.btnNhaCungCap.IsTab = true;
            this.btnNhaCungCap.Location = new System.Drawing.Point(3, 180);
            this.btnNhaCungCap.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNhaCungCap.Name = "btnNhaCungCap";
            this.btnNhaCungCap.Normalcolor = System.Drawing.Color.Transparent;
            this.btnNhaCungCap.OnHovercolor = System.Drawing.Color.White;
            this.btnNhaCungCap.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnNhaCungCap.selected = false;
            this.btnNhaCungCap.Size = new System.Drawing.Size(226, 59);
            this.btnNhaCungCap.TabIndex = 3;
            this.btnNhaCungCap.Text = "Nhà cung cấp";
            this.btnNhaCungCap.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNhaCungCap.Textcolor = System.Drawing.Color.Black;
            this.btnNhaCungCap.TextFont = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhaCungCap.Click += new System.EventHandler(this.btnNhaCungCap_Click);
            // 
            // btnKhachHang
            // 
            this.btnKhachHang.Activecolor = System.Drawing.Color.White;
            this.btnKhachHang.BackColor = System.Drawing.Color.Transparent;
            this.btnKhachHang.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnKhachHang.BorderRadius = 0;
            this.btnKhachHang.ButtonText = "Khách hàng";
            this.btnKhachHang.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnKhachHang.DisabledColor = System.Drawing.Color.Gray;
            this.btnKhachHang.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnKhachHang.Iconcolor = System.Drawing.Color.Transparent;
            this.btnKhachHang.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnKhachHang.Iconimage")));
            this.btnKhachHang.Iconimage_right = null;
            this.btnKhachHang.Iconimage_right_Selected = null;
            this.btnKhachHang.Iconimage_Selected = null;
            this.btnKhachHang.IconMarginLeft = 0;
            this.btnKhachHang.IconMarginRight = 0;
            this.btnKhachHang.IconRightVisible = false;
            this.btnKhachHang.IconRightZoom = 0D;
            this.btnKhachHang.IconVisible = false;
            this.btnKhachHang.IconZoom = 90D;
            this.btnKhachHang.IsTab = true;
            this.btnKhachHang.Location = new System.Drawing.Point(3, 121);
            this.btnKhachHang.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnKhachHang.Name = "btnKhachHang";
            this.btnKhachHang.Normalcolor = System.Drawing.Color.Transparent;
            this.btnKhachHang.OnHovercolor = System.Drawing.Color.White;
            this.btnKhachHang.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnKhachHang.selected = false;
            this.btnKhachHang.Size = new System.Drawing.Size(226, 59);
            this.btnKhachHang.TabIndex = 2;
            this.btnKhachHang.Text = "Khách hàng";
            this.btnKhachHang.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnKhachHang.Textcolor = System.Drawing.Color.Black;
            this.btnKhachHang.TextFont = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKhachHang.Click += new System.EventHandler(this.btnKhachHang_Click);
            // 
            // btnNhanVien
            // 
            this.btnNhanVien.Activecolor = System.Drawing.Color.White;
            this.btnNhanVien.BackColor = System.Drawing.Color.Transparent;
            this.btnNhanVien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNhanVien.BorderRadius = 0;
            this.btnNhanVien.ButtonText = "Nhân viên";
            this.btnNhanVien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNhanVien.DisabledColor = System.Drawing.Color.Gray;
            this.btnNhanVien.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNhanVien.Iconcolor = System.Drawing.Color.Transparent;
            this.btnNhanVien.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnNhanVien.Iconimage")));
            this.btnNhanVien.Iconimage_right = null;
            this.btnNhanVien.Iconimage_right_Selected = null;
            this.btnNhanVien.Iconimage_Selected = null;
            this.btnNhanVien.IconMarginLeft = 0;
            this.btnNhanVien.IconMarginRight = 0;
            this.btnNhanVien.IconRightVisible = false;
            this.btnNhanVien.IconRightZoom = 0D;
            this.btnNhanVien.IconVisible = false;
            this.btnNhanVien.IconZoom = 90D;
            this.btnNhanVien.IsTab = true;
            this.btnNhanVien.Location = new System.Drawing.Point(3, 62);
            this.btnNhanVien.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNhanVien.Name = "btnNhanVien";
            this.btnNhanVien.Normalcolor = System.Drawing.Color.Transparent;
            this.btnNhanVien.OnHovercolor = System.Drawing.Color.White;
            this.btnNhanVien.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnNhanVien.selected = false;
            this.btnNhanVien.Size = new System.Drawing.Size(226, 59);
            this.btnNhanVien.TabIndex = 1;
            this.btnNhanVien.Text = "Nhân viên";
            this.btnNhanVien.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNhanVien.Textcolor = System.Drawing.Color.Black;
            this.btnNhanVien.TextFont = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNhanVien.Click += new System.EventHandler(this.btnNhanVien_Click);
            // 
            // btnHangHoa
            // 
            this.btnHangHoa.Activecolor = System.Drawing.Color.White;
            this.btnHangHoa.BackColor = System.Drawing.Color.White;
            this.btnHangHoa.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHangHoa.BorderRadius = 0;
            this.btnHangHoa.ButtonText = "Hàng hóa";
            this.btnHangHoa.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHangHoa.DisabledColor = System.Drawing.Color.Gray;
            this.btnHangHoa.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHangHoa.Iconcolor = System.Drawing.Color.Transparent;
            this.btnHangHoa.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnHangHoa.Iconimage")));
            this.btnHangHoa.Iconimage_right = null;
            this.btnHangHoa.Iconimage_right_Selected = null;
            this.btnHangHoa.Iconimage_Selected = null;
            this.btnHangHoa.IconMarginLeft = 0;
            this.btnHangHoa.IconMarginRight = 0;
            this.btnHangHoa.IconRightVisible = false;
            this.btnHangHoa.IconRightZoom = 0D;
            this.btnHangHoa.IconVisible = false;
            this.btnHangHoa.IconZoom = 90D;
            this.btnHangHoa.IsTab = true;
            this.btnHangHoa.Location = new System.Drawing.Point(3, 3);
            this.btnHangHoa.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHangHoa.Name = "btnHangHoa";
            this.btnHangHoa.Normalcolor = System.Drawing.Color.Transparent;
            this.btnHangHoa.OnHovercolor = System.Drawing.Color.White;
            this.btnHangHoa.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnHangHoa.selected = true;
            this.btnHangHoa.Size = new System.Drawing.Size(226, 59);
            this.btnHangHoa.TabIndex = 0;
            this.btnHangHoa.Text = "Hàng hóa";
            this.btnHangHoa.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHangHoa.Textcolor = System.Drawing.Color.Black;
            this.btnHangHoa.TextFont = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHangHoa.Click += new System.EventHandler(this.btnHangHoa_Click);
            // 
            // btnBaoCaoTongHop
            // 
            this.btnBaoCaoTongHop.Activecolor = System.Drawing.Color.White;
            this.btnBaoCaoTongHop.BackColor = System.Drawing.Color.Transparent;
            this.btnBaoCaoTongHop.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBaoCaoTongHop.BorderRadius = 0;
            this.btnBaoCaoTongHop.ButtonText = "Tổng hợp";
            this.btnBaoCaoTongHop.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBaoCaoTongHop.DisabledColor = System.Drawing.Color.Gray;
            this.btnBaoCaoTongHop.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnBaoCaoTongHop.Iconcolor = System.Drawing.Color.Transparent;
            this.btnBaoCaoTongHop.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnBaoCaoTongHop.Iconimage")));
            this.btnBaoCaoTongHop.Iconimage_right = null;
            this.btnBaoCaoTongHop.Iconimage_right_Selected = null;
            this.btnBaoCaoTongHop.Iconimage_Selected = null;
            this.btnBaoCaoTongHop.IconMarginLeft = 0;
            this.btnBaoCaoTongHop.IconMarginRight = 0;
            this.btnBaoCaoTongHop.IconRightVisible = false;
            this.btnBaoCaoTongHop.IconRightZoom = 0D;
            this.btnBaoCaoTongHop.IconVisible = false;
            this.btnBaoCaoTongHop.IconZoom = 90D;
            this.btnBaoCaoTongHop.IsTab = true;
            this.btnBaoCaoTongHop.Location = new System.Drawing.Point(3, 363);
            this.btnBaoCaoTongHop.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnBaoCaoTongHop.Name = "btnBaoCaoTongHop";
            this.btnBaoCaoTongHop.Normalcolor = System.Drawing.Color.Transparent;
            this.btnBaoCaoTongHop.OnHovercolor = System.Drawing.Color.White;
            this.btnBaoCaoTongHop.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnBaoCaoTongHop.selected = false;
            this.btnBaoCaoTongHop.Size = new System.Drawing.Size(226, 60);
            this.btnBaoCaoTongHop.TabIndex = 8;
            this.btnBaoCaoTongHop.Text = "Tổng hợp";
            this.btnBaoCaoTongHop.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBaoCaoTongHop.Textcolor = System.Drawing.Color.Black;
            this.btnBaoCaoTongHop.TextFont = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBaoCaoTongHop.Click += new System.EventHandler(this.btnBaoCaoTongHop_Click);
            // 
            // btnNK
            // 
            this.btnNK.Activecolor = System.Drawing.Color.White;
            this.btnNK.BackColor = System.Drawing.Color.Transparent;
            this.btnNK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNK.BorderRadius = 0;
            this.btnNK.ButtonText = "Nhập kho";
            this.btnNK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNK.DisabledColor = System.Drawing.Color.Gray;
            this.btnNK.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnNK.Iconcolor = System.Drawing.Color.Transparent;
            this.btnNK.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnNK.Iconimage")));
            this.btnNK.Iconimage_right = null;
            this.btnNK.Iconimage_right_Selected = null;
            this.btnNK.Iconimage_Selected = null;
            this.btnNK.IconMarginLeft = 0;
            this.btnNK.IconMarginRight = 0;
            this.btnNK.IconRightVisible = false;
            this.btnNK.IconRightZoom = 0D;
            this.btnNK.IconVisible = false;
            this.btnNK.IconZoom = 90D;
            this.btnNK.IsTab = true;
            this.btnNK.Location = new System.Drawing.Point(3, 303);
            this.btnNK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNK.Name = "btnNK";
            this.btnNK.Normalcolor = System.Drawing.Color.Transparent;
            this.btnNK.OnHovercolor = System.Drawing.Color.White;
            this.btnNK.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnNK.selected = false;
            this.btnNK.Size = new System.Drawing.Size(226, 60);
            this.btnNK.TabIndex = 7;
            this.btnNK.Text = "Nhập kho";
            this.btnNK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNK.Textcolor = System.Drawing.Color.Black;
            this.btnNK.TextFont = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNK.Click += new System.EventHandler(this.btnNK_Click);
            // 
            // btnXK
            // 
            this.btnXK.Activecolor = System.Drawing.Color.White;
            this.btnXK.BackColor = System.Drawing.Color.Transparent;
            this.btnXK.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnXK.BorderRadius = 0;
            this.btnXK.ButtonText = "Xuất kho";
            this.btnXK.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnXK.DisabledColor = System.Drawing.Color.Gray;
            this.btnXK.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnXK.Iconcolor = System.Drawing.Color.Transparent;
            this.btnXK.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnXK.Iconimage")));
            this.btnXK.Iconimage_right = null;
            this.btnXK.Iconimage_right_Selected = null;
            this.btnXK.Iconimage_Selected = null;
            this.btnXK.IconMarginLeft = 0;
            this.btnXK.IconMarginRight = 0;
            this.btnXK.IconRightVisible = false;
            this.btnXK.IconRightZoom = 0D;
            this.btnXK.IconVisible = false;
            this.btnXK.IconZoom = 90D;
            this.btnXK.IsTab = true;
            this.btnXK.Location = new System.Drawing.Point(3, 243);
            this.btnXK.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnXK.Name = "btnXK";
            this.btnXK.Normalcolor = System.Drawing.Color.Transparent;
            this.btnXK.OnHovercolor = System.Drawing.Color.White;
            this.btnXK.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnXK.selected = false;
            this.btnXK.Size = new System.Drawing.Size(226, 60);
            this.btnXK.TabIndex = 6;
            this.btnXK.Text = "Xuất kho";
            this.btnXK.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnXK.Textcolor = System.Drawing.Color.Black;
            this.btnXK.TextFont = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXK.Click += new System.EventHandler(this.btnXK_Click);
            // 
            // btnHDNH
            // 
            this.btnHDNH.Activecolor = System.Drawing.Color.White;
            this.btnHDNH.BackColor = System.Drawing.Color.Transparent;
            this.btnHDNH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHDNH.BorderRadius = 0;
            this.btnHDNH.ButtonText = "HD Nhập hàng";
            this.btnHDNH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHDNH.DisabledColor = System.Drawing.Color.Gray;
            this.btnHDNH.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHDNH.Iconcolor = System.Drawing.Color.Transparent;
            this.btnHDNH.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnHDNH.Iconimage")));
            this.btnHDNH.Iconimage_right = null;
            this.btnHDNH.Iconimage_right_Selected = null;
            this.btnHDNH.Iconimage_Selected = null;
            this.btnHDNH.IconMarginLeft = 0;
            this.btnHDNH.IconMarginRight = 0;
            this.btnHDNH.IconRightVisible = false;
            this.btnHDNH.IconRightZoom = 0D;
            this.btnHDNH.IconVisible = false;
            this.btnHDNH.IconZoom = 90D;
            this.btnHDNH.IsTab = true;
            this.btnHDNH.Location = new System.Drawing.Point(3, 183);
            this.btnHDNH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHDNH.Name = "btnHDNH";
            this.btnHDNH.Normalcolor = System.Drawing.Color.Transparent;
            this.btnHDNH.OnHovercolor = System.Drawing.Color.White;
            this.btnHDNH.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnHDNH.selected = false;
            this.btnHDNH.Size = new System.Drawing.Size(226, 60);
            this.btnHDNH.TabIndex = 5;
            this.btnHDNH.Text = "HD Nhập hàng";
            this.btnHDNH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHDNH.Textcolor = System.Drawing.Color.Black;
            this.btnHDNH.TextFont = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHDNH.Click += new System.EventHandler(this.btnHDNH_Click);
            // 
            // btnHDBH
            // 
            this.btnHDBH.Activecolor = System.Drawing.Color.White;
            this.btnHDBH.BackColor = System.Drawing.Color.Transparent;
            this.btnHDBH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHDBH.BorderRadius = 0;
            this.btnHDBH.ButtonText = "HD Bán hàng";
            this.btnHDBH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHDBH.DisabledColor = System.Drawing.Color.Gray;
            this.btnHDBH.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnHDBH.Iconcolor = System.Drawing.Color.Transparent;
            this.btnHDBH.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnHDBH.Iconimage")));
            this.btnHDBH.Iconimage_right = null;
            this.btnHDBH.Iconimage_right_Selected = null;
            this.btnHDBH.Iconimage_Selected = null;
            this.btnHDBH.IconMarginLeft = 0;
            this.btnHDBH.IconMarginRight = 0;
            this.btnHDBH.IconRightVisible = false;
            this.btnHDBH.IconRightZoom = 0D;
            this.btnHDBH.IconVisible = false;
            this.btnHDBH.IconZoom = 90D;
            this.btnHDBH.IsTab = true;
            this.btnHDBH.Location = new System.Drawing.Point(3, 123);
            this.btnHDBH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnHDBH.Name = "btnHDBH";
            this.btnHDBH.Normalcolor = System.Drawing.Color.Transparent;
            this.btnHDBH.OnHovercolor = System.Drawing.Color.White;
            this.btnHDBH.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnHDBH.selected = false;
            this.btnHDBH.Size = new System.Drawing.Size(226, 60);
            this.btnHDBH.TabIndex = 4;
            this.btnHDBH.Text = "HD Bán hàng";
            this.btnHDBH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHDBH.Textcolor = System.Drawing.Color.Black;
            this.btnHDBH.TextFont = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnHDBH.Click += new System.EventHandler(this.btnHDBH_Click);
            // 
            // btnCTNH
            // 
            this.btnCTNH.Activecolor = System.Drawing.Color.White;
            this.btnCTNH.BackColor = System.Drawing.Color.Transparent;
            this.btnCTNH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCTNH.BorderRadius = 0;
            this.btnCTNH.ButtonText = "CT Nhập hàng";
            this.btnCTNH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCTNH.DisabledColor = System.Drawing.Color.Gray;
            this.btnCTNH.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCTNH.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCTNH.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnCTNH.Iconimage")));
            this.btnCTNH.Iconimage_right = null;
            this.btnCTNH.Iconimage_right_Selected = null;
            this.btnCTNH.Iconimage_Selected = null;
            this.btnCTNH.IconMarginLeft = 0;
            this.btnCTNH.IconMarginRight = 0;
            this.btnCTNH.IconRightVisible = false;
            this.btnCTNH.IconRightZoom = 0D;
            this.btnCTNH.IconVisible = false;
            this.btnCTNH.IconZoom = 90D;
            this.btnCTNH.IsTab = true;
            this.btnCTNH.Location = new System.Drawing.Point(3, 63);
            this.btnCTNH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCTNH.Name = "btnCTNH";
            this.btnCTNH.Normalcolor = System.Drawing.Color.Transparent;
            this.btnCTNH.OnHovercolor = System.Drawing.Color.White;
            this.btnCTNH.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnCTNH.selected = false;
            this.btnCTNH.Size = new System.Drawing.Size(226, 60);
            this.btnCTNH.TabIndex = 3;
            this.btnCTNH.Text = "CT Nhập hàng";
            this.btnCTNH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCTNH.Textcolor = System.Drawing.Color.Black;
            this.btnCTNH.TextFont = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCTNH.Click += new System.EventHandler(this.btnCTNH_Click);
            // 
            // btnCTBH
            // 
            this.btnCTBH.Activecolor = System.Drawing.Color.White;
            this.btnCTBH.BackColor = System.Drawing.Color.Transparent;
            this.btnCTBH.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCTBH.BorderRadius = 0;
            this.btnCTBH.ButtonText = "CT Bán hàng";
            this.btnCTBH.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCTBH.DisabledColor = System.Drawing.Color.Gray;
            this.btnCTBH.Dock = System.Windows.Forms.DockStyle.Top;
            this.btnCTBH.Iconcolor = System.Drawing.Color.Transparent;
            this.btnCTBH.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnCTBH.Iconimage")));
            this.btnCTBH.Iconimage_right = null;
            this.btnCTBH.Iconimage_right_Selected = null;
            this.btnCTBH.Iconimage_Selected = null;
            this.btnCTBH.IconMarginLeft = 0;
            this.btnCTBH.IconMarginRight = 0;
            this.btnCTBH.IconRightVisible = false;
            this.btnCTBH.IconRightZoom = 0D;
            this.btnCTBH.IconVisible = false;
            this.btnCTBH.IconZoom = 90D;
            this.btnCTBH.IsTab = true;
            this.btnCTBH.Location = new System.Drawing.Point(3, 3);
            this.btnCTBH.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCTBH.Name = "btnCTBH";
            this.btnCTBH.Normalcolor = System.Drawing.Color.Transparent;
            this.btnCTBH.OnHovercolor = System.Drawing.Color.White;
            this.btnCTBH.OnHoverTextColor = System.Drawing.Color.Black;
            this.btnCTBH.selected = true;
            this.btnCTBH.Size = new System.Drawing.Size(226, 60);
            this.btnCTBH.TabIndex = 2;
            this.btnCTBH.Text = "CT Bán hàng";
            this.btnCTBH.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCTBH.Textcolor = System.Drawing.Color.Black;
            this.btnCTBH.TextFont = new System.Drawing.Font("Times New Roman", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCTBH.Click += new System.EventHandler(this.btnCTBH_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.Location = new System.Drawing.Point(-8, 22);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(542, 2);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Location = new System.Drawing.Point(-2, 30);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(466, 2);
            this.panel2.TabIndex = 1;
            // 
            // supMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(179)))), ((int)(((byte)(179)))));
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.pnChe);
            this.Controls.Add(this.tabControl1);
            this.Name = "supMenu";
            this.Size = new System.Drawing.Size(246, 701);
            this.tabPage3.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Panel pnChe;
        private Bunifu.Framework.UI.BunifuFlatButton btnNhaCungCap;
        private Bunifu.Framework.UI.BunifuFlatButton btnKhachHang;
        private Bunifu.Framework.UI.BunifuFlatButton btnNhanVien;
        private Bunifu.Framework.UI.BunifuFlatButton btnHangHoa;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage6;
        private Bunifu.Framework.UI.BunifuFlatButton btnNK;
        private Bunifu.Framework.UI.BunifuFlatButton btnXK;
        private Bunifu.Framework.UI.BunifuFlatButton btnHDNH;
        private Bunifu.Framework.UI.BunifuFlatButton btnHDBH;
        private Bunifu.Framework.UI.BunifuFlatButton btnCTNH;
        private Bunifu.Framework.UI.BunifuFlatButton btnCTBH;
        private Bunifu.Framework.UI.BunifuFlatButton btnBaoCaoTongHop;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
    }
}
